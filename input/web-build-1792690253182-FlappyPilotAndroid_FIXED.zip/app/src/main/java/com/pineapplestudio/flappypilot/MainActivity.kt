package com.pineapplestudio.flappypilot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "Flappy Pilot\n\nАвтопилот для Flappy Bird-подобной игры.\n\n1. Включи службу ниже.\n2. Вернись в игру.\n3. Открой уведомления/настройки специальных возможностей и включи Flappy Pilot AI.\n4. Запусти автопилот кнопкой в приложении службы."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "Открыть специальные возможности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Открыть службу автопилота"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "\nВажно: Android требует вручную разрешить службу. Это экспериментальный CV-автопилот; он может ошибаться на другой версии игры."
            textSize = 14f
        })
        setContentView(layout)
    }
}

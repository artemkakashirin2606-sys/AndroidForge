# Flappy Pilot — Android project, buildable from a phone via GitHub Actions

This ZIP is **not an APK**. Renaming ZIP to APK will not work. The included GitHub Actions workflow builds an APK in GitHub's cloud; you do not need Android Studio or a PC.

## Build using only an Android phone
1. Download and extract this ZIP on your phone (for example, with Files or ZArchiver).
2. Open https://github.com and create a new repository. Public or private is fine.
3. Upload **the contents** of the extracted folder, including the `.github` folder. Do not upload the ZIP as a single file. If GitHub mobile web cannot upload folders, use GitHub's website in your browser with **Desktop site** enabled, or GitHub's upload-files page.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Flappy Pilot APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish successfully. Open that run, scroll to **Artifacts**, and download `FlappyPilot-debug-APK`.
7. Extract the downloaded artifact ZIP. Inside is `app-debug.apk`. Tap it to install; allow installation from that source if Android asks.

## Use
1. Open Flappy Pilot and tap “Открыть специальные возможности”.
2. Enable “Flappy Pilot AI” in Android Accessibility settings.
3. Open the target game. A floating “Flappy AI” button should appear.
4. Tap it to start/stop.

## Limitations
- Requires Android 11+ (API 30) for accessibility screenshots.
- This is a prototype using pixel-color heuristics, not a trained neural network. It may miss obstacles or tap at the wrong time, and is not guaranteed to beat every run.
- The service must be explicitly enabled by the user. Android may block screenshots in some protected apps.

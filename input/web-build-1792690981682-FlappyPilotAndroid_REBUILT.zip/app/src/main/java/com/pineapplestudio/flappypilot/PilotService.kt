package com.pineapplestudio.flappypilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Point
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import android.content.Context
import android.view.accessibility.AccessibilityEvent

class PilotService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var overlay: View? = null
    private var lastTap = 0L
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        showOverlay()
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopPilot() }

    private fun showOverlay() {
        if (overlay != null) return
        val button = Button(this).apply {
            text = "▶ Flappy AI"
            setOnClickListener {
                running = !running
                text = if (running) "■ Стоп AI" else "▶ Flappy AI"
                Toast.makeText(this@PilotService, if (running) "Автопилот включён" else "Автопилот остановлен", Toast.LENGTH_SHORT).show()
                if (running) loop()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        getSystemService(WindowManager::class.java).addView(button, params)
        overlay = button
    }

    private fun loop() {
        if (!running || busy) return
        busy = true
        takeScreenshot(0, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hardware = result.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(hardware, result.colorSpace)
                hardware.close()
                if (bitmap != null) {
                    try { analyze(bitmap) } finally { bitmap.recycle() }
                }
                busy = false
                if (running) handler.postDelayed({ loop() }, 115)
            }
            override fun onFailure(errorCode: Int) {
                busy = false
                if (running) handler.postDelayed({ loop() }, 350)
            }
        })
    }

    private fun analyze(b: Bitmap) {
        val w = b.width; val h = b.height
        if (w < 100 || h < 200) return
        // Find the game's blue playfield; sample columns to locate wooden obstacle bands.
        val xBird = (w * 0.30f).toInt()
        val sampleStep = maxOf(2, w / 240)
        val obstacleXs = mutableListOf<Int>()
        for (x in (xBird + w/12) until (w * 0.92f).toInt() step sampleStep) {
            var brown = 0
            for (y in (h*0.08f).toInt() until (h*0.92f).toInt() step maxOf(3,h/220)) {
                val c = b.getPixel(x,y)
                val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
                if (r in 90..190 && g in 45..135 && bl in 20..85 && r > g*1.25 && g > bl*1.15) brown++
            }
            if (brown > h/100) obstacleXs.add(x)
        }
        if (obstacleXs.isEmpty()) return
        val xCol = obstacleXs.first()
        // Find vertical wooden segments at the upcoming obstacle x.
        val ys = mutableListOf<Int>()
        for (y in (h*0.06f).toInt() until (h*0.94f).toInt() step maxOf(2,h/400)) {
            val c=b.getPixel(xCol,y); val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            if (r in 90..190 && g in 45..135 && bl in 20..85 && r > g*1.25 && g > bl*1.15) ys.add(y)
        }
        if (ys.isEmpty()) return
        // Longest clear vertical run is treated as the gap between upper and lower pipes.
        val bands = mutableListOf<Pair<Int,Int>>()
        var start=ys.first(); var prev=start
        for (y in ys.drop(1)) {
            if (y-prev > maxOf(5,h/100)) { bands.add(start to prev); start=y }
            prev=y
        }
        bands.add(start to prev)
        if (bands.size < 2) return
        val sorted = bands.sortedBy { it.first }
        var bestGap: Pair<Int,Int>? = null
        var bestSize = 0
        for (i in 0 until sorted.size-1) {
            val gap = sorted[i].second to sorted[i+1].first
            val size = gap.second-gap.first
            if (size > bestSize) { bestSize=size; bestGap=gap }
        }
        val gap=bestGap ?: return
        if (bestSize < h/18) return
        val gapCenter=(gap.first+gap.second)/2
        // Detect orange bird pixels near expected horizontal position.
        var sumY=0L; var count=0
        val x1=(w*0.18f).toInt(); val x2=(w*0.42f).toInt()
        val y1=(h*0.15f).toInt(); val y2=(h*0.82f).toInt()
        for (x in x1..x2 step maxOf(2,w/300)) for (y in y1..y2 step maxOf(2,h/300)) {
            val c=b.getPixel(x,y); val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            if (r>175 && g in 65..190 && bl<95 && r>g*1.25) { sumY+=y; count++ }
        }
        if (count < 4) return
        val birdY=(sumY/count).toInt()
        val now=System.currentTimeMillis()
        // Small dead band prevents rapid tapping; tap when bird is below the gap's center.
        if (birdY > gapCenter + h*0.025f && now-lastTap > 155) {
            val path=Path().apply { moveTo(w*0.5f,h*0.5f); lineTo(w*0.5f,h*0.5f) }
            dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,45)).build(), null, null)
            lastTap=now
        }
    }

    private fun stopPilot() { running=false }
    override fun onDestroy() {
        stopPilot()
        val oldOverlay = overlay
        if (oldOverlay != null) {
            try { getSystemService(WindowManager::class.java).removeView(oldOverlay) } catch (_: Exception) {}
        }
        overlay = null
        super.onDestroy()
    }
}

# Flappy Pilot (Android)

Experimental Android AccessibilityService overlay for a Flappy-Bird-like game.

## Build

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35 and Java 17. It can be built with `gradle assembleDebug` in an Android SDK environment, or by a cloud Android builder that supports standard Gradle Android projects.

Expected APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Install / use

1. Install the generated APK.
2. Open Flappy Pilot and use its button to open Android Accessibility settings.
3. Enable the Flappy Pilot AI service.
4. Return to the target game and use the floating `Flappy AI` button to start/stop.

This is a heuristic prototype, not a trained AI and not guaranteed to beat every clone. It reads screenshots using Android's accessibility screenshot API and taps based on approximate brown-obstacle/orange-player colors. Android may restrict screenshots in protected apps, and different game graphics may need tuning.

# Flappy Pilot (Android source ZIP)

An experimental Android AccessibilityService overlay that samples screenshots and taps to control a Flappy-Bird-like game.

## Build
- Open this ZIP in AndroidForge as an Android source ZIP.
- The project uses Android Gradle Plugin 8.7.3, compileSdk 35, Java 17, and minSdk 30.
- No external libraries are required.

## Setup on phone
1. Install the generated debug APK.
2. Open Flappy Pilot and tap **Открыть настройки доступности**.
3. Enable the Flappy Pilot accessibility service.
4. Open the target game and tap the floating **Flappy AI** button.
5. Tap the same button again to stop.

## Important limitations
This is not machine-learning AI. It uses simple pixel-colour heuristics tuned to the provided screenshot style; it may not recognize different obstacle colours, game layouts, scaling, or bird sprites. Android screenshot capture through AccessibilityService requires Android 11 (API 30) or newer. This source archive has not been built or device-tested in this environment, so successful APK generation and gameplay are not guaranteed.

package com.pineapplestudio.flappypilot;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(Color.rgb(14, 20, 32));
        TextView title = new TextView(this);
        title.setText("Flappy Pilot"); title.setTextSize(30); title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER); title.setPadding(0, dp(16), 0, dp(18));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this);
        info.setText("Автопилот для Flappy Bird-подобных игр.\n\n1. Разреши службу доступности.\n2. Открой игру.\n3. Нажми плавающую кнопку «Flappy AI».\n\nВажно: распознавание препятствий основано на цветах и может не подходить к каждой копии игры. Сначала проверь на коротком запуске.");
        info.setTextSize(17); info.setTextColor(Color.rgb(220, 228, 240)); info.setLineSpacing(dp(5), 1f);
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));
        Button settings = new Button(this); settings.setText("Открыть настройки доступности");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings, new LinearLayout.LayoutParams(-1, -2));
        TextView footer = new TextView(this); footer.setText("Pineapple Studio · экспериментальная версия"); footer.setTextColor(Color.LTGRAY); footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(18), 0, 0);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}

package com.pineapplestudio.flappypilot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

public class PilotService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false, busy = false;
    private View overlay;
    private long lastTap = 0;

    @Override public void onServiceConnected() { super.onServiceConnected(); showOverlay(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { running = false; }

    private void showOverlay() {
        if (overlay != null) return;
        Button button = new Button(this);
        button.setText("▶ Flappy AI");
        button.setAllCaps(false);
        button.setOnClickListener(v -> {
            running = !running;
            button.setText(running ? "■ Стоп AI" : "▶ Flappy AI");
            Toast.makeText(this, running ? "Автопилот включён" : "Автопилот остановлен", Toast.LENGTH_SHORT).show();
            if (running) loop();
        });
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END; p.x = 12; p.y = 180;
        try { getSystemService(WindowManager.class).addView(button, p); overlay = button; }
        catch (Exception e) { Toast.makeText(this, "Не удалось показать кнопку автопилота", Toast.LENGTH_LONG).show(); }
    }

    private void loop() {
        if (!running || busy) return;
        busy = true;
        try {
            takeScreenshot(0, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap bitmap = null;
                    HardwareBuffer buffer = result.getHardwareBuffer();
                    try {
                        bitmap = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                        if (bitmap != null) analyze(bitmap);
                    } catch (Exception ignored) { }
                    finally {
                        if (bitmap != null) bitmap.recycle();
                        buffer.close();
                        busy = false;
                        if (running) handler.postDelayed(PilotService.this::loop, 140);
                    }
                }
                @Override public void onFailure(int errorCode) {
                    busy = false;
                    if (running) handler.postDelayed(PilotService.this::loop, 400);
                }
            });
        } catch (Exception e) {
            busy = false;
            if (running) handler.postDelayed(this::loop, 500);
        }
    }

    private boolean brown(int c) {
        int r=Color.red(c), g=Color.green(c), b=Color.blue(c);
        return r >= 90 && r <= 195 && g >= 40 && g <= 140 && b >= 15 && b <= 95 && r > g * 1.20 && g > b * 1.10;
    }

    private void analyze(Bitmap image) {
        int w=image.getWidth(), h=image.getHeight();
        if (w < 150 || h < 250) return;
        int birdX=(int)(w*0.30f), sampleX=(int)(w*0.42f);
        // Scan several x positions and use the nearest column with brown pixels.
        int chosen=-1, bestX=Integer.MAX_VALUE;
        for (int x=(int)(w*0.36f); x<(int)(w*0.85f); x+=Math.max(3,w/180)) {
            int count=0;
            for (int y=(int)(h*0.08f); y<(int)(h*0.92f); y+=Math.max(3,h/180)) if (brown(image.getPixel(x,y))) count++;
            if (count > 5 && x < bestX) { chosen=x; bestX=x; }
        }
        if (chosen < 0) return;
        int top=-1, bottom=-1; boolean seenBrown=false; int gapStart=-1, gapEnd=-1;
        int step=Math.max(2,h/360);
        for (int y=(int)(h*0.06f); y<(int)(h*0.94f); y+=step) {
            boolean isBrown=brown(image.getPixel(chosen,y));
            if (isBrown) { if (!seenBrown && gapStart>=0) { gapEnd=y; break; } seenBrown=true; top=y; }
            else if (seenBrown) { seenBrown=false; gapStart=y; }
            else if (gapStart<0 && !isBrown) { /* upper region */ }
        }
        // More robust gap estimate: find longest non-brown vertical run between brown pixels.
        int runStart=-1, longest=0; int upperEnd=-1, lowerStart=-1; boolean foundUpper=false;
        for (int y=(int)(h*0.06f); y<(int)(h*0.94f); y+=step) {
            boolean br=brown(image.getPixel(chosen,y));
            if (br) { if (runStart>=0) { int len=y-runStart; if (foundUpper && len>longest) { longest=len; upperEnd=runStart; lowerStart=y; } } foundUpper=true; runStart=-1; }
            else if (runStart<0) runStart=y;
        }
        if (longest < h*0.08f || upperEnd<0 || lowerStart<0) return;
        int gapCenter=(upperEnd+lowerStart)/2;
        long sum=0; int count=0;
        for (int x=(int)(w*0.12f); x<(int)(w*0.40f); x+=Math.max(2,w/260)) {
            for (int y=(int)(h*0.12f); y<(int)(h*0.88f); y+=Math.max(2,h/260)) {
                int c=image.getPixel(x,y), r=Color.red(c), g=Color.green(c), b=Color.blue(c);
                if (r>175 && g>55 && g<195 && b<105 && r>g*1.15) { sum+=y; count++; }
            }
        }
        if (count < 5) return;
        int birdY=(int)(sum/(double)count);
        long now=System.currentTimeMillis();
        // Tap only when bird is lower than the estimated opening center.
        if (birdY > gapCenter + h*0.035f && now-lastTap>180) {
            Path path=new Path(); path.moveTo(w*0.5f,h*0.5f);
            GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
            if (dispatchGesture(gesture,null,null)) lastTap=now;
        }
    }

    @Override public void onDestroy() {
        running=false; handler.removeCallbacksAndMessages(null);
        if (overlay != null) { try { getSystemService(WindowManager.class).removeView(overlay); } catch (Exception ignored) { } overlay=null; }
        super.onDestroy();
    }
}

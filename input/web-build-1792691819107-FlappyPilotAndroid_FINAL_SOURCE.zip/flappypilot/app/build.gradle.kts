plugins { id("com.android.application") }

android {
    namespace = "com.pineapplestudio.flappypilot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.pineapplestudio.flappypilot"
        minSdk = 30
        targetSdk = 32
        versionCode = 1
        versionName = "1.0.1"
    }
}
